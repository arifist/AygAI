import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import RandomForestClassifier
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score
import joblib


# ---------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------
#preprocessing

# df = pd.read_excel("airline_clnd.xlsx")

# df["satisfaction"] = df["satisfaction"].map({"neutral or dissatisfied": 0, "satisfied": 1})

# df["Gender"] = df["Gender"].map({"Male": 0, "Female": 1})

# df["Customer_Type"] = df["Customer_Type"].map({"Loyal Customer": 0, "disloyal Customer": 1})

# df["Type_of_Travel"] = df["Type_of_Travel"].map({"Personal Travel": 0, "Business travel": 1})

# df["Class"] = df["Class"].map({"Eco Plus": 0,"Eco": 0, "Business": 1})


# df.to_excel("guncellenmis_airline_clnd.xlsx", index=False)

df = pd.read_excel("guncellenmis_airline_clnd.xlsx")

#colab
# drive.mount('/content/drive')
# df=pd.read_csv('/content/drive/MyDrive/Sentiment/guncellenmis_airline_clnd.xlsx')


# ---------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------
#ozellik onemi analizi

# X = df.drop(columns=["satisfaction"])
X = df[['Inflight_wifi_service', 'Departure/Arrival_time_convenient', 'Ease_of_Online_booking', 
          'Gate_location', 'Food_and_drink', 'Online_boarding', 'Seat_comfort', 
          'Inflight_entertainment', 'On-board_service', 'Leg_room_service', 'Baggage_handling', 
          'Checkin_service', 'Inflight_service', 'Cleanliness']]
y = df["satisfaction"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

feature_importances = model.feature_importances_

print("Özelliklerin Genel Memnuniyet Puanına Katkısı:")
for i, feature in enumerate(X.columns):
    print(f"{feature}: {feature_importances[i]}")


feature_importance_df = pd.DataFrame({"Feature": X.columns, "Importance": feature_importances})
feature_importance_df = feature_importance_df.sort_values(by="Importance", ascending=False)

sns.set_style("whitegrid")

plt.figure(figsize=(10, 8))
plt.pie(feature_importance_df["Importance"], labels=feature_importance_df["Feature"], autopct='%1.1f%%', startangle=140, colors=sns.color_palette("muted"))
plt.axis('equal')
plt.title('Özelliklerin Genel Memnuniyet Puanına Katkısı')
plt.show()


# Çubuk grafiği oluşturma
plt.figure(figsize=(10, 8))
sns.barplot(x="Importance", y="Feature", data=feature_importance_df, palette="viridis")
plt.title('Özelliklerin Genel Memnuniyet Puanına Katkısı')
plt.xlabel('Önem Derecesi')
plt.ylabel('Özellikler')
plt.show()
    



# ---------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------
# # gozetimli model egitimi


X = df[['Inflight_wifi_service', 'Departure/Arrival_time_convenient', 'Ease_of_Online_booking', 
          'Gate_location', 'Food_and_drink', 'Online_boarding', 'Seat_comfort', 
          'Inflight_entertainment', 'On-board_service', 'Leg_room_service', 'Baggage_handling', 
          'Checkin_service', 'Inflight_service', 'Cleanliness']]
y = df['satisfaction']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
print("Doğruluk: {:.2f}%".format(accuracy * 100))



sample_input = {
    'Inflight_wifi_service': 1,
    'Departure/Arrival_time_convenient': 1,
    'Ease_of_Online_booking': 1,
    'Gate_location': 2,
    'Food_and_drink': 1,
    'Online_boarding': 1,
    'Seat_comfort': 1,
    'Inflight_entertainment': 2,
    'On-board_service': 2,
    'Leg_room_service': 2,
    'Baggage_handling': 2,
    'Checkin_service': 1,
    'Inflight_service': 2,
    'Cleanliness': 3
}

sample_input_df = pd.DataFrame(sample_input, index=[0])

satisfaction_prediction = model.predict(sample_input_df)

if satisfaction_prediction[0] == 0:
    print("Bu müşterinin memnuniyet puanı düşük.")
else:
    print("Bu müşterinin memnuniyet puanı yüksek.")
    
# Modeli kaydet
joblib.dump(model, 'model.pkl')

print("Model başarıyla eğitildi ve kaydedildi!")


from sklearn.metrics import accuracy_score, confusion_matrix

# Karışıklık matrisi hesaplama
conf_matrix = confusion_matrix(y_test, y_pred)

# Karışıklık matrisini görselleştirme
plt.figure(figsize=(10, 7))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=['Düşük Memnuniyet', 'Yüksek Memnuniyet'], yticklabels=['Düşük Memnuniyet', 'Yüksek Memnuniyet'])
plt.xlabel('Tahmin Edilen')
plt.ylabel('Gerçek')
plt.title(f'Karışıklık Matrisi (Doğruluk: {accuracy * 100:.2f}%)')
plt.show()

# ---------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------


#gozetimsiz ogrenme modeli


# ---------------------------------------------------------------------------------------------------------
# gozetimsiz ogrenim modeli

import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt
import seaborn as sns

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Performans değerlendirme: En iyi küme sayısını belirleme
inertia = []
silhouette_scores = []
k_range = range(2, 11)  # 2'den 10'a kadar olan küme sayıları

for k in k_range:
    kmeans = KMeans(n_clusters=k, random_state=42)
    kmeans.fit(X_scaled)

    inertia.append(kmeans.inertia_)
    silhouette_avg = silhouette_score(X_scaled, kmeans.labels_)
    silhouette_scores.append(silhouette_avg)

# Performans değerlendirme
plt.figure(figsize=(12, 6))

# Elbow yöntemi grafiği
plt.subplot(1, 2, 1)
plt.plot(k_range, inertia, marker='o')
plt.title('Elbow Method for Optimal k')
plt.xlabel('Number of Clusters (k)')
plt.ylabel('Inertia')

# Silhouette skorları grafiği
plt.subplot(1, 2, 2)
plt.plot(k_range, silhouette_scores, marker='o')
plt.title('Silhouette Score for Optimal k')
plt.xlabel('Number of Clusters (k)')
plt.ylabel('Silhouette Score')

plt.tight_layout()
plt.show()

# En iyi küme sayısını seçmek
optimal_k = k_range[silhouette_scores.index(max(silhouette_scores))]

# K-means modelini eğit
kmeans = KMeans(n_clusters=optimal_k, random_state=42)
kmeans.fit(X_scaled)
df['Cluster'] = kmeans.labels_

# Küme merkezlerini görselleştirme
plt.figure(figsize=(10, 8))
sns.scatterplot(x=df['Inflight_wifi_service'], y=df['Seat_comfort'], hue=df['Cluster'], palette='viridis', s=100, alpha=0.6)
plt.title('K-means Clustering')
plt.xlabel('Inflight Wifi Service')
plt.ylabel('Seat Comfort')
plt.legend(title='Cluster')
plt.show()

# Küme merkezlerinin görselleştirilmesi
centers = scaler.inverse_transform(kmeans.cluster_centers_)
centers_df = pd.DataFrame(centers, columns=X.columns)

print("Küme Merkezleri:")
print(centers_df)


